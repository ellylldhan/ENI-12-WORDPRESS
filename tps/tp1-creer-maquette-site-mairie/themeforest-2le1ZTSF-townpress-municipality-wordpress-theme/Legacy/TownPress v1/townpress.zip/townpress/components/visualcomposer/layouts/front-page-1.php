<?php return array(
	'name' => __( '#Front Page 1', 'lsvrtheme' ),
	'custom_class' => 'lsvr-layout-template lsvr-layout-template-front-page-1',
	'content' => '[vc_row][vc_column width="1/1"][lsvr_directory icon="tp tp-road-sign" menu="" columns="3" title="Choose <strong>Your Interest</strong>"][lsvr_articles category="none" icon="tp tp-reading" number_of_items="5" highlight_first="yes" more_btn_label="Read All Posts" title="TownPress <strong>News</strong>"][/vc_column][/vc_row]'
); ?>