<?php return array(
	'name' => __( '#Town Council', 'lsvrtheme' ),
	'custom_class' => 'lsvr-layout-template lsvr-layout-template-town-council',
	'content' => '[vc_row][vc_column width="1/2"][lsvr_team_member wpautop="yes" portrait="1835" name="Mathias Oliver" role="Town Clerk"]Phone: (123) 456-7890
Email: <a href="#">clerk@townpress.gov</a>[/lsvr_team_member][/vc_column][vc_column width="1/2"][lsvr_team_member wpautop="yes" portrait="1840" name="Justina Glenice" role="Finance Manager"]Phone: (123) 456-7891
Email: <a href="#">finances@townpress.gov</a>[/lsvr_team_member][/vc_column][/vc_row][vc_row][vc_column width="1/2"][lsvr_team_member wpautop="yes" portrait="1842" name="Valeria Decima" role="Administrative Officer"]Phone: (123) 456-7892
Email: <a href="#">administration@townpress.gov</a>[/lsvr_team_member][/vc_column][vc_column width="1/2"][lsvr_team_member wpautop="yes" portrait="1841" name="Ivar Otmar" role="Operations Manager"]Phone: (123) 456-7894
Email: <a href="#">operations@townpress.gov</a>[/lsvr_team_member][/vc_column][/vc_row][vc_row][vc_column width="1/2"][lsvr_team_member wpautop="yes" portrait="1851" name="Avril Margareta" role="Administrative Assistant"]Phone: (123) 456-7898
Email: <a href="#">administration@townpress.gov</a>[/lsvr_team_member][/vc_column][vc_column width="1/2"][lsvr_team_member wpautop="yes" portrait="1844" name="Judith Leone" role="Finance Assistant"]Phone: (123) 456-7891
Email: <a href="#">finances@townpress.gov</a>[/lsvr_team_member][/vc_column][/vc_row][vc_row][vc_column width="1/2"][lsvr_team_member wpautop="yes" portrait="1845" name="David Myron" role="Enforcement Officer"]Phone: (123) 456-7897
Email: <a href="#">townhall@townpress.gov</a>[/lsvr_team_member][/vc_column][vc_column width="1/2"][lsvr_team_member wpautop="yes" portrait="1843" name="Daly Rodolfo" role="Maintenance Operative"]Phone: (123) 456-7893
Email: <a href="#">townhall@townpress.gov</a>[/lsvr_team_member][/vc_column][/vc_row]'
); ?>