<?php

/**
 * Display the event time
 */
if ( ! function_exists( 'lsvr_events_the_event_time' ) ) {
	function lsvr_events_the_event_time( $event_occurrence ) {

		// All-day event
        if ( ! empty( $event_occurrence['allday'] ) && true === $event_occurrence['allday'] ) {

            esc_html_e( 'All-day event', 'lsvr-events' );

        }

        // Display start and end time
        elseif ( ! empty( $event_occurrence['postid'] ) && 'true' === get_post_meta( $event_occurrence['postid'], 'lsvr_event_end_time_enable', true ) ) {

            echo sprintf( esc_html__( '%s - %s', 'lsvr-events' ),
                lsvr_events_get_event_local_start_time( $event_occurrence['postid'] ),
                lsvr_events_get_event_local_end_time( $event_occurrence['postid'] )
            );

        }

        // Display only start time
        else {

            echo esc_html( lsvr_events_get_event_local_start_time( $event_occurrence['postid'] ) );

        }

    }
}

?>