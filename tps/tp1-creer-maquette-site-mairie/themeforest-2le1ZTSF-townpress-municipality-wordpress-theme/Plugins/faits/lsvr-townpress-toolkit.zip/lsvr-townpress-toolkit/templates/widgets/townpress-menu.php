<?php global $lsvr_template_vars;
if ( ! empty( $lsvr_template_vars ) && is_array( $lsvr_template_vars ) ) : extract( $lsvr_template_vars );

// TEMPLATE : BEGIN ?>

<div class="widget__content">

	<?php if ( ! empty( $instance['menu_id'] ) && is_nav_menu( $instance['menu_id'] ) && class_exists( 'Lsvr_Townpress_Menu_Widget_Walker' ) ) : ?>

		<nav class="lsvr-townpress-menu-widget__nav<?php if ( true === $show_active ) { echo esc_attr( ' lsvr-townpress-menu-widget__nav--expanded-active' ); } ?>"
			data-label-expand-submenu="<?php echo esc_attr( esc_html__( 'Expand submenu', 'lsvr-townpress-toolkit' ) ); ?>"
			data-label-collapse-submenu="<?php echo esc_attr( esc_html__( 'Collapse submenu', 'lsvr-townpress-toolkit' ) ); ?>"

			<?php if ( ! empty( $menu_object->name ) ) : ?>

				aria-label="<?php echo esc_attr( $menu_object->name ); ?>"

			<?php endif; ?>>

		    <?php wp_nav_menu(
		        array(
		            'menu' => $instance['menu_id'],
					'container' => '',
					'menu_class' => 'lsvr-townpress-menu-widget__list',
					'fallback_cb' => '',
					'items_wrap' => '<ul id="%1$s" class="%2$s" role="menu">%3$s</ul>',
					'walker' => new Lsvr_Townpress_Menu_Widget_Walker(),
				)
			); ?>

		</nav>

	<?php endif; ?>

</div>

<?php // TEMPLATE : END
endif; ?>