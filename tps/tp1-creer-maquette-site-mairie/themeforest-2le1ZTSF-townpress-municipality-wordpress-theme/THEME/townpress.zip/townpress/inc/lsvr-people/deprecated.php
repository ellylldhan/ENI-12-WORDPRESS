<?php

// Get person archive layout
if ( ! function_exists( 'lsvr_townpress_get_person_archive_layout' ) ) {
	function lsvr_townpress_get_person_archive_layout() {

		trigger_error( sprintf( LSVR_TOWNPRESS_DEPRECATED_ERROR_MSG, __METHOD__ ), E_USER_DEPRECATED );

		return 'default';

	}
}

?>