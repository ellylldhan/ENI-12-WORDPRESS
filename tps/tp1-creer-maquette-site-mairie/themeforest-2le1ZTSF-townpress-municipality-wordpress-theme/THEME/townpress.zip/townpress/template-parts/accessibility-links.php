<?php if ( true === get_theme_mod( 'improved_accessibility_enable', true ) ) : ?>

	<a href="#main" class="accessibility-link accessibility-link--skip-to-content screen-reader-text"><?php esc_html_e( 'Skip to content', 'townpress' ); ?></a>

	<?php if ( is_active_sidebar( apply_filters( 'lsvr_townpress_sidebar_left_id', 'lsvr-townpress-default-sidebar-left' ) ) ) : ?>
		<a href="#sidebar-left" class="accessibility-link accessibility-link--skip-to-left-sidebar screen-reader-text"><?php esc_html_e( 'Skip to left sidebar', 'townpress' ); ?></a>
	<?php endif; ?>

	<?php if ( is_active_sidebar( apply_filters( 'lsvr_townpress_sidebar_right_id', '' ) ) ) : ?>
		<a href="#sidebar-right" class="accessibility-link accessibility-link--skip-to-right-sidebar screen-reader-text"><?php esc_html_e( 'Skip to right sidebar', 'townpress' ); ?></a>
	<?php endif; ?>

	<a href="#footer" class="accessibility-link accessibility-link--skip-to-footer screen-reader-text"><?php esc_html_e( 'Skip to footer', 'townpress' ); ?></a>

<?php endif; ?>