<?php // Ended event
if ( ! lsvr_townpress_has_next_event_occurrences( get_the_ID() ) ) : ?>

	<?php lsvr_townpress_the_alert_message( esc_html__( 'This event has ended', 'townpress' ) ); ?>

<?php elseif ( lsvr_townpress_is_recurring_event( get_the_ID() ) && lsvr_townpress_has_next_event_occurrences( get_the_ID() ) ) : ?>

	<h2 class="post__next-date-title"><?php esc_html_e( 'Next Date', 'townpress' ); ?></h2>

<?php endif; ?>

<!-- POST INFO : begin -->
<ul class="post__info<?php if ( lsvr_townpress_is_multiday_event( get_the_ID() ) ) { echo ' post__info--multiday'; } else { echo ' post__info--singleday'; } ?>">

	<?php // Date
	get_template_part( 'template-parts/lsvr_event/single-date' ); ?>

	<?php // Address
	get_template_part( 'template-parts/lsvr_event/single-address' ); ?>

</ul>
<!-- POST INFO : end -->