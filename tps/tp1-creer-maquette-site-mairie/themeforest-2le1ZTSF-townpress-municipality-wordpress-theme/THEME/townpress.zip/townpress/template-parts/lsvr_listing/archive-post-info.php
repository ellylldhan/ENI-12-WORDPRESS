<?php if ( lsvr_townpress_has_post_terms( get_the_ID(), 'lsvr_listing_cat' ) ||
	lsvr_townpress_has_listing_address( get_the_ID() ) ) : ?>

	<!-- POST INFO : begin -->
	<ul class="post__info" aria-label="<?php echo esc_attr( esc_html__( 'Listing Information', 'townpress' ) ); ?>">

		<?php if ( lsvr_townpress_has_listing_address( get_the_ID() ) ) : ?>

			<!-- POST ADDRESS : begin -->
			<li class="post__info-item post__info-item--location" title="<?php echo esc_attr( esc_html__( 'Address', 'townpress' ) ); ?>">

				<span class="post__info-item-icon post__info-item-icon--location" aria-hidden="true"></span>

				<?php lsvr_townpress_the_listing_address( get_the_ID() ); ?>
			</li>
			<!-- POST ADDRESS : end -->

		<?php endif; ?>

		<?php if ( lsvr_townpress_has_post_terms( get_the_ID(), 'lsvr_listing_cat' ) ) : ?>

			<!-- POST META : begin -->
			<li class="post__info-item post__info-item--category" title="<?php echo esc_attr( esc_html__( 'Category', 'townpress' ) ); ?>">

				<span class="post__info-item-icon post__info-item-icon--category" aria-hidden="true"></span>

				<?php lsvr_townpress_the_post_terms( get_the_ID(), 'lsvr_listing_cat', esc_html__( '%s', 'townpress' ) ); ?>

			</li>
			<!-- POST META : end -->

		<?php endif; ?>

	</ul>
	<!-- POST INFO : end -->

<?php endif; ?>