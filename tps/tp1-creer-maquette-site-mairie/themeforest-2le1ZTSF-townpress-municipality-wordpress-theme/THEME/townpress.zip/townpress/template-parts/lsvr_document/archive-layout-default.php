<!-- DOCUMENT POST ARCHIVE : begin -->
<div class="lsvr_document-post-page post-archive lsvr_document-post-archive lsvr_document-post-archive--default">

	<?php // Main header
	get_template_part( 'template-parts/main-header' ); ?>

	<?php // Archive categories
	get_template_part( 'template-parts/archive-categories' ); ?>

	<?php // Archive category description
	get_template_part( 'template-parts/archive-category-description' ); ?>

	<?php if ( have_posts() ) : ?>

		<!-- POST ARCHIVE LIST : begin -->
		<div class="post-archive__list">

			<?php while ( have_posts() ) : the_post(); ?>

				<!-- POST : begin -->
				<article <?php post_class( 'post' ); ?>>
					<div class="c-content-box post__inner">

						<!-- POST HEADER : begin -->
						<header class="post__header">

							<!-- POST TITLE : begin -->
							<h2 class="post__title">
								<a href="<?php the_permalink(); ?>" class="post__title-link" rel="bookmark"><?php the_title(); ?></a>
							</h2>
							<!-- POST TITLE : end -->

						</header>
						<!-- POST HEADER : end -->

						<?php if ( ! empty( $post->post_excerpt ) ) : ?>

							<!-- POST CONTENT : begin -->
							<div class="post__content">
								<?php the_excerpt(); ?>
							</div>
							<!-- POST CONTENT : end -->

						<?php endif; ?>

						<?php // Post attachments
						get_template_part( 'template-parts/lsvr_document/attachments' ); ?>

						<?php // Post footer
						get_template_part( 'template-parts/archive-post-footer' ); ?>

					</div>
				</article>
				<!-- POST : end -->

			<?php endwhile; ?>

		</div>
		<!-- POST ARCHIVE LIST : end -->

		<?php // Pagination
		the_posts_pagination(); ?>

	<?php else : ?>

		<?php lsvr_townpress_the_alert_message( esc_html__( 'There are no documents', 'townpress' ) ); ?>

	<?php endif; ?>

</div>
<!-- DOCUMENT POST ARCHIVE : end -->