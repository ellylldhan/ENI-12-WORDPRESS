<!-- COLUMNS : begin -->
<div id="columns">
	<div class="columns__inner">
		<div class="lsvr-container">

			<?php if ( is_active_sidebar( apply_filters( 'lsvr_townpress_sidebar_left_id', 'lsvr-townpress-default-sidebar-left' ) )
				&& is_active_sidebar( apply_filters( 'lsvr_townpress_sidebar_right_id', '' ) ) ) : ?>

				<div class="lsvr-grid">
					<div class="columns__main lsvr-grid__col lsvr-grid__col--span-6 lsvr-grid__col--push-3">

			<?php elseif ( is_active_sidebar( apply_filters( 'lsvr_townpress_sidebar_left_id', 'lsvr-townpress-default-sidebar-left' ) ) ) : ?>

				<div class="lsvr-grid">
					<div class="columns__main lsvr-grid__col lsvr-grid__col--span-9 lsvr-grid__col--push-3">

			<?php elseif ( is_active_sidebar( apply_filters( 'lsvr_townpress_sidebar_right_id', '' ) ) ) : ?>

				<div class="lsvr-grid">
					<div class="columns__main lsvr-grid__col lsvr-grid__col--span-9">

			<?php endif; ?>

			<!-- MAIN : begin -->
			<main id="main">
				<div class="main__inner">