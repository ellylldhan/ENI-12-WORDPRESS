<!-- PAGE CONTENT : begin -->
<div class="page__content">

	<div class="c-content-box">

		<?php the_content(); ?>
		<?php wp_link_pages(); ?>

	</div>

    <?php // Post comments
    if ( comments_open() ) : ?>

    	<div class="c-content-box">
    		<?php comments_template(); ?>
    	</div>

    <?php endif; ?>

</div>
<!-- PAGE CONTENT : end -->