<?php if ( has_nav_menu( 'lsvr-townpress-footer-menu' ) ) : ?>

	<!-- FOOTER MENU : begin -->
	<nav class="footer-menu"

		<?php if ( ! empty( lsvr_townpress_get_menu_name_by_location( 'lsvr-townpress-footer-menu' ) ) ) : ?>
			aria-label="<?php echo lsvr_townpress_get_menu_name_by_location( 'lsvr-townpress-footer-menu' ); ?>"
		<?php endif; ?>>

	    <?php wp_nav_menu(
	        array(
	            'theme_location' => 'lsvr-townpress-footer-menu',
				'container' => '',
				'menu_class' => 'footer-menu__list',
				'fallback_cb' => '',
				'items_wrap' => '<ul id="%1$s" class="%2$s" role="menu">%3$s</ul>',
				'depth' => 1,
			)
		); ?>

	</nav>
	<!-- FOOTER MENU : end -->

<?php endif; ?>