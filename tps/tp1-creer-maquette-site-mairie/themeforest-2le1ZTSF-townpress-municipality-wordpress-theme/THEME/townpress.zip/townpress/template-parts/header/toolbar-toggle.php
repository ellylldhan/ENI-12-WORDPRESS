<!-- HEADER TOOLBAR TOGGLE : begin -->
<div class="header-toolbar-toggle<?php if ( true === apply_filters( 'lsvr_townpress_header_map_enable', false ) ) { echo ' header-toolbar-toggle--has-map'; } ?>">

	<button class="header-toolbar-toggle__menu-button" type="button"
		aria-controls="header-mobile-menu"
        aria-haspopup="true"
        aria-expanded="false">
		<span class="header-toolbar-toggle__menu-button-ico header-toolbar-toggle__menu-button-ico--open icon-menu" aria-hidden="true"></span>
		<span class="header-toolbar-toggle__menu-button-ico header-toolbar-toggle__menu-button-ico--close icon-cross" aria-hidden="true"></span>
		<span class="header-toolbar-toggle__menu-button-label"><?php esc_html_e( 'Menu', 'townpress' ); ?></span>
	</button>

	<?php // Mobile map toggle
	get_template_part( 'template-parts/header/map-toggle-mobile' ); ?>

</div>
<!-- HEADER TOOLBAR TOGGLE : end -->