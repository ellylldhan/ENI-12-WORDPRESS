<?php // Add custom code before Header toolbar
do_action( 'lsvr_townpress_header_toolbar_before' ); ?>

<?php if ( true === apply_filters( 'lsvr_townpress_header_toolbar_enable', false ) ) : ?>

	<?php // Mobile toolbar toggle
	get_template_part( 'template-parts/header/toolbar-toggle' ); ?>

	<!-- HEADER TOOLBAR : begin -->
	<div class="header-toolbar">

		<?php // Add custom code at the top of Header toolbar
		do_action( 'lsvr_townpress_header_toolbar_top' ); ?>

		<?php // Language switcher
		get_template_part( 'template-parts/header/languages' ); ?>

		<?php // Add custom code after header languages
		do_action( 'lsvr_townpress_header_languages_after' ); ?>

		<?php // Header map toggle
		get_template_part( 'template-parts/header/map-toggle' ); ?>

		<?php // Add custom code after header map toggle
		do_action( 'lsvr_townpress_header_map_toggle_after' ); ?>

		<?php // Header login
		get_template_part( 'template-parts/header/login' ); ?>

		<?php // Add custom code after header login
		do_action( 'lsvr_townpress_header_login_after' ); ?>

		<?php // Mobile menu
		get_template_part( 'template-parts/header/mobile-menu' ); ?>

		<?php // Add custom code after header mobile menu
		do_action( 'lsvr_townpress_header_mobile_menu_after' ); ?>

		<?php // Header search
		get_template_part( 'template-parts/header/search' ); ?>

		<?php // Add custom code at the bottom of Header toolbar
		do_action( 'lsvr_townpress_header_toolbar_bottom' ); ?>

	</div>
	<!-- HEADER TOOLBAR : end -->

<?php endif; ?>

<?php // Add custom code after Header toolbar
do_action( 'lsvr_townpress_header_toolbar_after' ); ?>