<?php if ( true === apply_filters( 'lsvr_townpress_header_map_enable', false ) ) : ?>

	<!-- HEADER MAP TOGGLE : begin -->
	<button class="header-map-toggle header-map-toggle--desktop header-toolbar__item" type="button"
		aria-label="<?php esc_html_e( 'Open / close map', 'townpress' ); ?>">
		<span class="header-map-toggle__ico header-map-toggle__ico--open icon-map2" aria-hidden="true"></span>
		<span class="header-map-toggle__ico header-map-toggle__ico--close icon-cross" aria-hidden="true"></span>
		<span class="header-map-toggle__label"><?php echo esc_html( get_theme_mod( 'header_map_toggle_label', esc_html__( 'Map', 'townpress' ) ) ); ?></span>
	</button>
	<!-- HEADER MAP TOGGLE : end -->

<?php endif;