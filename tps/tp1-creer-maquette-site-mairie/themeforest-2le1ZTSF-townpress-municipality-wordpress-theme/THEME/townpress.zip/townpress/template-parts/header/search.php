<?php if ( true === (bool) get_theme_mod( 'header_search_enable', true ) ) : ?>

	<!-- HEADER SEARCH : begin -->
	<div class="header-search header-toolbar__item">

		<?php get_search_form() ?>

	</div>
	<!-- HEADER SEARCH : end -->

<?php endif; ?>