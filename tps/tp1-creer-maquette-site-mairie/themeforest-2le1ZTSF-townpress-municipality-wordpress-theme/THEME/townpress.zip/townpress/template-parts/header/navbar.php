<?php if ( true === apply_filters( 'lsvr_townpress_header_navbar_enable', false ) ) : ?>

	<!-- HEADER NAVBAR : begin -->
	<div <?php lsvr_townpress_the_header_navbar_class(); ?>>
		<div class="header-navbar__inner">

			<div class="lsvr-container">

				<!-- HEADER MENU : begin -->
				<nav class="header-menu"

					<?php if ( ! empty( lsvr_townpress_get_menu_name_by_location( 'lsvr-townpress-header-menu' ) ) ) : ?>
						aria-label="<?php echo lsvr_townpress_get_menu_name_by_location( 'lsvr-townpress-header-menu' ); ?>"
					<?php endif; ?>>

				    <?php wp_nav_menu(
				        array(
				            'theme_location' => 'lsvr-townpress-header-menu',
							'container' => '',
							'menu_class' => 'header-menu__list',
							'fallback_cb' => '',
							'items_wrap' => '<ul id="%1$s" class="%2$s" role="menu">%3$s</ul>',
							'walker' => new Lsvr_Townpress_Header_Menu_Walker(),
						)
					); ?>

				</nav>
				<!-- HEADER MENU : end -->

			</div>

		</div>
	</div>
	<!-- HEADER NAVBAR : end -->

<?php endif; ?>