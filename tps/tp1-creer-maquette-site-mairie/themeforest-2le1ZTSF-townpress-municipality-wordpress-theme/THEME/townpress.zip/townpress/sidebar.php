<?php if ( is_active_sidebar( apply_filters( 'lsvr_townpress_sidebar_left_id', 'lsvr-townpress-default-sidebar-left' ) ) ) : ?>

	<!-- LEFT SIDEBAR : begin -->
	<aside id="sidebar-left">
		<div class="sidebar-left__inner">

			<?php dynamic_sidebar( apply_filters( 'lsvr_townpress_sidebar_left_id', 'lsvr-townpress-default-sidebar-left' ) ); ?>

		</div>
	</aside>
	<!-- LEFT SIDEBAR : end -->

<?php endif; ?>
