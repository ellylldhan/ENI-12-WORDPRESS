<?php if ( is_active_sidebar( apply_filters( 'lsvr_townpress_sidebar_right_id', '' ) ) ) : ?>

	<!-- RIGHT SIDEBAR : begin -->
	<aside id="sidebar-right">
		<div class="sidebar-right__inner">

			<?php dynamic_sidebar( apply_filters( 'lsvr_townpress_sidebar_right_id', '' ) ); ?>

		</div>
	</aside>
	<!-- RIGHT SIDEBAR : end -->

<?php endif; ?>
